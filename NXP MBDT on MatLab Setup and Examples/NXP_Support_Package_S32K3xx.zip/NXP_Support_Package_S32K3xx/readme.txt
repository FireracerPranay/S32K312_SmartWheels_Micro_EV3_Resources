*************************************************************************************
NXP Support Package for S32K3xx v.1.5.0 Release
10 June 2024

NXP(TM) and the NXP logo are trademarks of NXP Semiconductors, Inc.
All other product or service names are the property of their respective owners.
(C) NXP Semiconductors, Inc. 2024
*************************************************************************************

This package contains NXP Support Package for S32K3xx v.1.5.0 which is the
step-by-step installer for the NXP Model-Based Desing Toolbox for S32K3xx and
the additional software and tools needed to simulate, build and deploy of
embedded applications to NXP S32K3xx Series of MCUs

To run the installer invoke NXP_Support_Package_S32K3xx in MATLAB Command Window

For support, please use this link: https://community.nxp.com/community/mbdt


*************************************************************************************
This document contains additional information about the product.

--------------------------------------------------------
NXP Support Package S32K3xx v.1.5.0 Release
--------------------------------------------------------
 - Updated for v.1.5.0

*************************************************************************************
Release History

--------------------------------------------------------
NXP Support Package S32K3xx v.1.4.0 Release
--------------------------------------------------------
 - Updated for v.1.4.0

--------------------------------------------------------
NXP Support Package S32K3xx v.1.3.0 Release
--------------------------------------------------------
 - Updated for v.1.3.0

--------------------------------------------------------
NXP Support Package S32K3xx v.1.2.0 Release
--------------------------------------------------------
 - Updated for v.1.2.0

--------------------------------------------------------
NXP Support Package S32K3xx v.1.1.0 Release
--------------------------------------------------------
 - Updated for v.1.1.0

--------------------------------------------------------
NXP Support Package S32K3xx v.1.0.0 Release
--------------------------------------------------------
  -  First public release