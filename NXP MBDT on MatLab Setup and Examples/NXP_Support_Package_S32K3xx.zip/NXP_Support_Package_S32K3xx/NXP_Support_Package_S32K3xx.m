% Copyright 2024 NXP
% 
% NXP Confidential and Proprietary. This software is owned or controlled by
% NXP and may only be used strictly in accordance with the applicable
% license terms. By expressly accepting such terms or by downloading,
% installing, activating and/or otherwise using the software, you are
% agreeing that you have read, and that you agree to comply with and are
% bound by, such license terms. If you do not agree to be bound by the
% applicable license terms, then you may not retain, install, activate or
% otherwise use the software.

classdef NXP_Support_Package_S32K3xx < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        figure1              matlab.ui.Figure
        NXPPage              matlab.ui.control.Button
        Help                 matlab.ui.control.Button
        uipanel6             matlab.ui.container.Panel
        mbdt_version         matlab.ui.control.DropDown
        text24               matlab.ui.control.Label
        Close                matlab.ui.control.Button
        uipanel4             matlab.ui.container.Panel
        Convert              matlab.ui.control.Button
        text36               matlab.ui.control.Label
        LicenseVerification  matlab.ui.control.Button
        ActivateLicense      matlab.ui.control.Button
        text32               matlab.ui.control.Label
        License              matlab.ui.control.Button
        text30               matlab.ui.control.Label
        OpenToolbox          matlab.ui.control.Button
        Install              matlab.ui.control.Button
        Download             matlab.ui.control.Button
        text3                matlab.ui.control.Label
        uipanel3             matlab.ui.container.Panel
        nxp_logo             matlab.ui.control.Image
        text25               matlab.ui.control.Label
        text15               matlab.ui.control.Label
        signup               matlab.ui.control.Button
        text4                matlab.ui.control.Label
        text2                matlab.ui.control.Label
    end


    properties (Access = private)
        ToolboxName = 'S32K3XX'; % Description
    end

    methods (Access = private)

        % Function checking the toolbox name and version  and return:
        % 0 - OK
        % 1 - BAD TOOLBOX
        % 2 - BAD VERSION
        function out = CheckToolboxNameVersion(app, filename, version)
            out = 0; % OK
            % Check the filename
            if ~contains(filename, ['_', app.ToolboxName, '_'], "IgnoreCase", true)
                out = 1; % BAD TOOLBOX
            elseif ~contains(filename, version)
                out = 2; % BAD VERSION
            end
        end

    end


    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function NXP_Support_Package_S32K3xx_OpeningFcn(app, varargin)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app); %#ok<ASGLU>

            % Choose default command line output for NXP_Support_Package_S32K3xx
            handles.output = hObject;
            handles.path = pwd;

            % Update handles structure
            guidata(hObject, handles);
            movegui(gcf,'center')
        end

        % Button pushed function: Download
        function DownloadToolbox_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            handles = guidata(hObject);
            user_selection = get(handles.mbdt_version,'Value');
            switch (user_selection)
                case {1}
                    % 1.5.0
                    web https://nxp.flexnetoperations.com/control/frse/download?element=3983098 -browser
                    set(handles.Download,'BackgroundColor',[0.1 1 0.4]);
                case {2}
                    % 1.4.0
                    web https://nxp.flexnetoperations.com/control/frse/download?element=14146527 -browser
                    set(handles.Download,'BackgroundColor',[0.1 1 0.4]);
                case {3}
                    % 1.3.0
                    web https://nxp.flexnetoperations.com/control/frse/download?element=13957417 -browser
                    set(handles.Download,'BackgroundColor',[0.1 1 0.4]);
                case {4}
                    % 1.2.0
                    web https://nxp.flexnetoperations.com/control/frse/download?element=13593437 -browser
                    set(handles.Download,'BackgroundColor',[0.1 1 0.4]);
                case {5}
                    % 1.1.0
                    web https://nxp.flexnetoperations.com/control/frse/download?element=12920897 -browser
                    set(handles.Download,'BackgroundColor',[0.1 1 0.4]);
                case {6}
                    %1.0.0
                    web https://nxp.flexnetoperations.com/control/frse/download?element=12747097 -browser
                    set(handles.Download,'BackgroundColor',[0.1 1 0.4]);
                otherwise
                    % should not reach out here, but just in case for the future
                    warndlg ('OOPS! No valid version found');
                    set(handles.OpenToolbox,'BackgroundColor',[0.9 0.1 0.1]);
            end
        end

        % Button pushed function: Convert
        function ConvertToolbox_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            convert = false;
            user_selection = get(handles.mbdt_version,'Value');
            mbdt_version = get(handles.mbdt_version,'String');

            [filename, pathname, filterindex] = uigetfile( ...
                {  '*.zip','Toolbox Archive File (*.zip)'; ...
                '*.*',  'All Files (*.*)'}, ...
                'Pick a file', ...
                'MultiSelect', 'off');

            % Check to see if a file has been selected
            if ~isequal(filename,0) || ~isequal(pathname,0)

                % Check if we have a .zip file because the option was 'All Files'
                if endsWith (filename, '.zip', "IgnoreCase", true)
                    convert = true;
                else
                    errordlg('Please select a *.zip file!');
                end

                % Check the version and make sure the user wants to
                % continue
                switch app.CheckToolboxNameVersion(filename, mbdt_version)
                    case 0
                        convert = true;
                    case 1
                        errordlg(['Please provide a *.zip file for Model-Based Design Toolbox for ', app.ToolboxName]);
                        convert = false;
                    case 2
                        user_option = questdlg('A mismatch between the toolbox version and the selected file has been detected. Are you sure you wish to proceed with the selected file installation?',...
                            'Mismatch warning',...
                            'Yes','No','No');
                        if strcmpi(user_option,'Yes')
                            convert = true;
                        end
                end

                % Converting process
                if convert
                    out = movefile(fullfile(pathname, filename), fullfile(pathname, strrep(lower(filename), '.zip', '.mltbx')), 'f');
                    if out
                        set(handles.Convert,'BackgroundColor',[0.1 1 0.4]);
                        convert = true;
                    else
                        convert = false;
                    end
                end
                if ~convert
                    set(handles.Convert,'BackgroundColor',[0.9 0.1 0.1]);
                end
            end
        end

        % Button pushed function: Install
        function InstallToolbox_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            user_selection = get(handles.mbdt_version,'Value');
            mbdt_version = get(handles.mbdt_version,'String');

            [filename, pathname, filterindex] = uigetfile( ...
                {  '*.mltbx','Matlab Toolbox File (*.mltbx)'; ...
                '*.*',  'All Files (*.*)'}, ...
                'Pick a file', ...
                'MultiSelect', 'off');

            install = false;

            % Check to see if a file has been selected
            if ~isequal(filename,0) || ~isequal(pathname,0)

                % Check if we have a .zip file because the option was 'All Files'
                if endsWith (filename, '.mltbx', "IgnoreCase", true)
                    install = true;
                else
                    errordlg('Please select a *.mltbx file!');
                end

                % Check the version and make sure the user wants to
                % continue
                switch app.CheckToolboxNameVersion(filename, mbdt_version)
                    case 0
                        install = true;
                    case 1
                        errordlg(['Please provide a *.mltbx file for Model-Based Design Toolbox for ', app.ToolboxName]);
                        install = false;
                    case 2
                        user_option = questdlg('A mismatch between the toolbox version and the selected file has been detected. Are you sure you wish to proceed with the selected file installation?',...
                            'Mismatch warning',...
                            'Yes','No','No');
                        if strcmpi(user_option,'Yes')
                            install = true;
                        end
                end

                % Installing process
                if install
                    uiopen(fullfile(pathname,filename),1);
                    set(handles.Install,'BackgroundColor',[0.1 1 0.4]);
                end
                if ~install
                    set(handles.Install,'BackgroundColor',[0.9 0.1 0.1]);
                end
            end
        end

        % Button pushed function: OpenToolbox
        function OpenToolbox_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            user_selection = get(handles.mbdt_version,'Value');
            mbdt_version   = get(handles.mbdt_version,'String');
            toolboxes = matlab.addons.toolbox.installedToolboxes;
            result  = zeros;
            for i = 1 : length(toolboxes)
                result(i) = contains(toolboxes(i).Name, 'NXP_MBDToolbox_S32K3xx');
            end

            if any(result)
                uiwait(msgbox('NXP Model-Based Design Toolbox for S32K3xx was installed successfully','Info','modal'));
                cd(mbd_find_s32k3_root);
                set(handles.OpenToolbox,'BackgroundColor',[0.1 1 0.4]);
            else
                uiwait(msgbox({'NXP Model-Based Design Toolbox for S32K3xx was not found!', ...
                    'Please check Add-Ons/Manage Add-Ons menu to verify if the toolbox exists',...
                    'If you have installed a previous version in the past you may want to remove it manually before installing again'},'Warning','modal'));
                set(handles.OpenToolbox,'BackgroundColor',[0.9 0.1 0.1]);
            end
        end

        % Button pushed function: License
        function GenerateLicense_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            user_selection = get(handles.mbdt_version,'Value');
            switch (user_selection)
                case {1}
                    %web https://www.nxp.com/webapp/swlicensing/sso/downloadSoftware.sp?catid=SW32K3-STDSW-D -browser
                    web https://nxp.flexnetoperations.com/control/frse/dload_serialNum?item_key=3983098 -browser
                    set(handles.License,'BackgroundColor',[0.1 1 0.4]);
                case {2}
                    %web https://www.nxp.com/webapp/swlicensing/sso/downloadSoftware.sp?catid=SW32K3-STDSW-D -browser
                    web https://nxp.flexnetoperations.com/control/frse/dload_serialNum?item_key=14146527 -browser
                    set(handles.License,'BackgroundColor',[0.1 1 0.4]);
                case {3}
                    %web https://www.nxp.com/webapp/swlicensing/sso/downloadSoftware.sp?catid=SW32K3-STDSW-D -browser
                    web https://nxp.flexnetoperations.com/control/frse/dload_serialNum?item_key=13957417 -browser
                    set(handles.License,'BackgroundColor',[0.1 1 0.4]);
                case {4}
                    %web https://www.nxp.com/webapp/swlicensing/sso/downloadSoftware.sp?catid=SW32K3-STDSW-D -browser
                    web https://nxp.flexnetoperations.com/control/frse/dload_serialNum?item_key=13593437 -browser
                    set(handles.License,'BackgroundColor',[0.1 1 0.4]);
                case {5}
                    %web https://www.nxp.com/webapp/swlicensing/sso/downloadSoftware.sp?catid=SW32K3-STDSW-D -browser
                    web https://nxp.flexnetoperations.com/control/frse/dload_serialNum?item_key=12920897 -browser
                    set(handles.License,'BackgroundColor',[0.1 1 0.4]);
                case {6}
                    %web https://www.nxp.com/webapp/swlicensing/sso/downloadSoftware.sp?catid=SW32K3-STDSW-D -browser
                    web https://nxp.flexnetoperations.com/control/frse/dload_serialNum?item_key=12747097 -browser
                    set(handles.License,'BackgroundColor',[0.1 1 0.4]);
                otherwise
                    % should not reach out here, but just in case for the future
                    warndlg ('OOPS! No valid version found');
                    set(handles.License,'BackgroundColor',[0.9 0.1 0.1]);
            end
        end

        % Button pushed function: ActivateLicense
        function ActivateLicense_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            [filename, pathname, ~] = uigetfile( ...
                {'*.dat','NXP MBD Toolbox license file (*.dat)'; ...
                '*.lic','NXP MBD Toolbox license file (*.lic)'; ...
                '*.*',  'All Files (*.*)'}, ...
                'Pick a license file', ...
                'MultiSelect', 'off');
            if ~isequal(filename,0) || ~isequal(pathname,0)
                toolboxes = matlab.addons.toolbox.installedToolboxes;
                result = zeros;
                for i = 1 : length(toolboxes)
                    result(i) = contains(toolboxes(i).Name, 'NXP_MBDToolbox_S32K3xx');
                end
                if any(result)
                    [out, msg] = copyfile(fullfile(pathname,filename),fullfile(mbd_find_s32k3_root,'lic'));
                    if out
                        set(handles.ActivateLicense,'BackgroundColor',[0.1 1 0.4]);
                    else
                        errordlg(msg);
                        set(handles.ActivateLicense,'BackgroundColor',[0.9 0.1 0.1]);
                    end
                else
                    uiwait(msgbox({'NXP Model-Based Design Toolbox for S32K3xx was not found!', ...
                        'Please check Add-Ons/Manage Add-Ons menu to verify if the toolbox exists'},'Warning','modal'));
                    set(handles.ActivateLicense,'BackgroundColor',[0.9 0.1 0.1]);
                end
            end
        end

        % Button pushed function: LicenseVerification
        function VerifyLicense_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            try
                toolboxes = matlab.addons.toolbox.installedToolboxes;
                result = zeros;
                for i = 1 : length(toolboxes)
                    result(i) = contains(toolboxes(i).Name, 'NXP_MBDToolbox_S32K3xx');
                end
                if any(result)
                    if ( mbd_s32k3.common.nxp.checker.check_lic_expire(gcs) == 0 )
                        uiwait(msgbox({'NXP Model-Based Design Toolbox for S32K3xx license activation was successful!','Enjoy using this toolbox'},'Info','modal'));
                        set(handles.LicenseVerification,'BackgroundColor',[0.1 1 0.4]);
                    else
                        uiwait(errordlg('NXP Model-Based Design Toolbox license activation failed','License Error','modal'));
                        set(handles.LicenseVerification,'BackgroundColor',[0.9 0.1 0.1]);
                    end
                else
                    uiwait(msgbox({'NXP Model-Based Design Toolbox for S32K3xx was not found!', ...
                        'Please check Add-Ons/Manage Add-Ons menu to verify if this toolbox exists'},'Warning','modal'));
                    set(handles.LicenseVerification,'BackgroundColor',[0.9 0.1 0.1]);
                end
            catch ME
                uiwait(errordlg(ME.message,'License Error','modal'));
                set(handles.LicenseVerification,'BackgroundColor',[0.9 0.1 0.1]);
            end
        end

        % Button pushed function: NXPPage
        function NXPPage_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            web https://www.nxp.com/mbdt -browser
        end

        % Button pushed function: signup
        function SignUp_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            web https://www.nxp.com/webapp-signup/register -browser
        end

        % Button pushed function: Help
        function Help_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            web https://community.nxp.com/community/mbdt -browser
        end

        % Button pushed function: Close
        function Close_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>

            close
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create figure1 and hide until all components are created
            app.figure1 = uifigure('Visible', 'off');
            app.figure1.Color = [1 1 1];
            app.figure1.Position = [50 40 644 579];
            app.figure1.Name = 'NXP''s Model-Based Design Toolbox for S32K3xx: Installation Guide';
            app.figure1.Resize = 'off';
            app.figure1.HandleVisibility = 'callback';
            app.figure1.Tag = 'figure1';

            % Create uipanel3
            app.uipanel3 = uipanel(app.figure1);
            app.uipanel3.BackgroundColor = [1 1 1];
            app.uipanel3.Tag = 'uipanel3';
            app.uipanel3.FontSize = 11;
            app.uipanel3.Position = [10 307 625 235];

            % Create text2
            app.text2 = uilabel(app.uipanel3);
            app.text2.Tag = 'text2';
            app.text2.BackgroundColor = [1 1 1];
            app.text2.VerticalAlignment = 'top';
            app.text2.FontSize = 11;
            app.text2.Position = [258 81 362 145];
            app.text2.Text = {'The NXP''s Model-Based Design Toolbox provides an integrated '; 'development environment and toolchain for configuring and '; 'generating all of the necessary software automatically (including'; 'initialization routines and device drivers) to execute complex '; 'applications (e.g.: motor control algorithms, communication '; 'protocols or sensor-based applications) on NXP S32K3xx MCUs.'; ''; 'This wizard is design to guide you throughout download, installation and'; 'activation of the Model-Based Design Toolbox for S32K3xx.'; ''; 'Select one of the available actions below to proceed...'};

            % Create text4
            app.text4 = uilabel(app.uipanel3);
            app.text4.Tag = 'text4';
            app.text4.BackgroundColor = [1 1 1];
            app.text4.VerticalAlignment = 'top';
            app.text4.FontSize = 8;
            app.text4.FontColor = [0.149019607843137 0.149019607843137 0.149019607843137];
            app.text4.Position = [258 17 230 33];
            app.text4.Text = {'Use https://www.nxp.com/signup/register to create a new account.'; 'The NXP account gives access to free content on the '; 'NXP''s Model-Based Design Community:'};

            % Create signup
            app.signup = uibutton(app.uipanel3, 'push');
            app.signup.ButtonPushedFcn = createCallbackFcn(app, @SignUp_Callback, true);
            app.signup.Tag = 'signup';
            app.signup.FontSize = 11;
            app.signup.Position = [485 11 130 28];
            app.signup.Text = 'Sign up now!';

            % Create text15
            app.text15 = uilabel(app.uipanel3);
            app.text15.Tag = 'text15';
            app.text15.BackgroundColor = [1 1 1];
            app.text15.VerticalAlignment = 'top';
            app.text15.FontSize = 8;
            app.text15.FontColor = [0.850980392156863 0.329411764705882 0.101960784313725];
            app.text15.Position = [258 50 354 15];
            app.text15.Text = 'Note: A valid NXP account is needed to access to NXP Download page.';

            % Create text25
            app.text25 = uilabel(app.uipanel3);
            app.text25.Tag = 'text25';
            app.text25.BackgroundColor = [1 1 1];
            app.text25.VerticalAlignment = 'top';
            app.text25.FontSize = 8;
            app.text25.FontColor = [0 0 1];
            app.text25.Position = [258 4 196 14];
            app.text25.Text = 'https://community.nxp.com/community/mbdt';

            % Create nxp_logo
            app.nxp_logo = uiimage(app.uipanel3);
            app.nxp_logo.Tag = 'nxp_logo';
            app.nxp_logo.Position = [10 11 234 215];
            app.nxp_logo.ImageSource = 'Installer_Guide_Logo_S32K3xx.png';

            % Create text3
            app.text3 = uilabel(app.figure1);
            app.text3.Tag = 'text3';
            app.text3.BackgroundColor = [1 1 1];
            app.text3.VerticalAlignment = 'top';
            app.text3.FontSize = 13;
            app.text3.Position = [7 552 635 18];
            app.text3.Text = 'Installation Guide for NXP''s Model-Based Design Toolbox for S32K3xx Microprocessors Family';

            % Create uipanel4
            app.uipanel4 = uipanel(app.figure1);
            app.uipanel4.ForegroundColor = [0.650980392156863 0.650980392156863 0.650980392156863];
            app.uipanel4.Title = 'Download and Install the NXP MBD Toolbox for S32K3xx';
            app.uipanel4.BackgroundColor = [1 1 1];
            app.uipanel4.Tag = 'uipanel4';
            app.uipanel4.FontSize = 11;
            app.uipanel4.Position = [10 57 624 186];

            % Create Download
            app.Download = uibutton(app.uipanel4, 'push');
            app.Download.ButtonPushedFcn = createCallbackFcn(app, @DownloadToolbox_Callback, true);
            app.Download.Tag = 'Download';
            app.Download.FontSize = 11;
            app.Download.Tooltip = {'Click here to open the NXP website download location of the NXP Model-Based Design Toolbox for S32K3xx.Log-in with a valid NXP account and download the *.mltbx file on your computer.'};
            app.Download.Position = [51 103 215 28];
            app.Download.Text = 'Go To NXP Download Site';

            % Create Install
            app.Install = uibutton(app.uipanel4, 'push');
            app.Install.ButtonPushedFcn = createCallbackFcn(app, @InstallToolbox_Callback, true);
            app.Install.Tag = 'Install';
            app.Install.FontSize = 11;
            app.Install.Tooltip = {'Click here to install the NXP Model-Based Design Toolbox *.mltbx file.MATLAB will display a pop up window once the Add-on installation is completed.This might take up to 5 minutes.'};
            app.Install.Position = [51 38 215 28];
            app.Install.Text = 'Install MLTBX File as Add-On';

            % Create OpenToolbox
            app.OpenToolbox = uibutton(app.uipanel4, 'push');
            app.OpenToolbox.ButtonPushedFcn = createCallbackFcn(app, @OpenToolbox_Callback, true);
            app.OpenToolbox.Tag = 'OpenToolbox';
            app.OpenToolbox.FontSize = 11;
            app.OpenToolbox.Tooltip = {'Click here to verify if the NXP Model-Based Design Toolbox for S32K3xx was installed correctly and to navigate to toolbox root directory.'};
            app.OpenToolbox.Position = [51 6 215 28];
            app.OpenToolbox.Text = 'Verify MBD Toolbox Installation';

            % Create text30
            app.text30 = uilabel(app.uipanel4);
            app.text30.Tag = 'text30';
            app.text30.BackgroundColor = [1 1 1];
            app.text30.VerticalAlignment = 'top';
            app.text30.FontSize = 7;
            app.text30.FontColor = [0.650980392156863 0.650980392156863 0.650980392156863];
            app.text30.Position = [270 43 77 19];
            app.text30.Text = {'***Installation might '; 'take several minutes'};

            % Create License
            app.License = uibutton(app.uipanel4, 'push');
            app.License.ButtonPushedFcn = createCallbackFcn(app, @GenerateLicense_Callback, true);
            app.License.Tag = 'License';
            app.License.FontSize = 11;
            app.License.Tooltip = {'Click here to open the NXP website and generate a cost free, node locked permanent license file. Check the online documentation for details.You need to provide the Disk ID for the HDD partition on which the toolbox is installed. i.e.: use Windows CMD and type: vol C: to obtain the Disk ID.'};
            app.License.Position = [368 103 215 28];
            app.License.Text = 'Generate License File';

            % Create text32
            app.text32 = uilabel(app.uipanel4);
            app.text32.Tag = 'text32';
            app.text32.BackgroundColor = [1 1 1];
            app.text32.VerticalAlignment = 'top';
            app.text32.FontSize = 11;
            app.text32.Position = [330 138 293 25];
            app.text32.Text = {'Step 2: Generate a free-of-cost license from NXP website,'; '             download and install into toolbox License folder.'};

            % Create ActivateLicense
            app.ActivateLicense = uibutton(app.uipanel4, 'push');
            app.ActivateLicense.ButtonPushedFcn = createCallbackFcn(app, @ActivateLicense_Callback, true);
            app.ActivateLicense.Tag = 'ActivateLicense';
            app.ActivateLicense.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.ActivateLicense.FontSize = 11;
            app.ActivateLicense.Tooltip = {'Click here to activate the downloaded *.lic or *.dat file.'};
            app.ActivateLicense.Position = [368 70 215 28];
            app.ActivateLicense.Text = 'Activate NXP MBD Toolbox';

            % Create LicenseVerification
            app.LicenseVerification = uibutton(app.uipanel4, 'push');
            app.LicenseVerification.ButtonPushedFcn = createCallbackFcn(app, @VerifyLicense_Callback, true);
            app.LicenseVerification.Tag = 'LicenseVerification';
            app.LicenseVerification.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.LicenseVerification.FontSize = 11;
            app.LicenseVerification.Tooltip = {'Click here to verify if the MBDT License has been successfully installed.'};
            app.LicenseVerification.Position = [368 38 215 28];
            app.LicenseVerification.Text = 'Verify MBD Toolbox License';

            % Create text36
            app.text36 = uilabel(app.uipanel4);
            app.text36.Tag = 'text36';
            app.text36.BackgroundColor = [1 1 1];
            app.text36.VerticalAlignment = 'top';
            app.text36.FontSize = 11;
            app.text36.Position = [15 138 308 25];
            app.text36.Text = {'Step 1: Download the NXP S32K3xx Toolbox from NXP website '; '            and install it as Add-On using MATLAB installer.'};

            % Create Convert
            app.Convert = uibutton(app.uipanel4, 'push');
            app.Convert.ButtonPushedFcn = createCallbackFcn(app, @ConvertToolbox_Callback, true);
            app.Convert.Tag = 'Convert';
            app.Convert.FontSize = 11;
            app.Convert.Tooltip = {'If the downloaded file is .zip archive, click here to convert the *.zip file into *.mltbx.'};
            app.Convert.Position = [51 70 215 28];
            app.Convert.Text = 'Convert .ZIP to .MLTBX';

            % Create Close
            app.Close = uibutton(app.figure1, 'push');
            app.Close.ButtonPushedFcn = createCallbackFcn(app, @Close_Callback, true);
            app.Close.Tag = 'Close';
            app.Close.FontSize = 11;
            app.Close.Position = [497 13 130 28];
            app.Close.Text = 'Close';

            % Create uipanel6
            app.uipanel6 = uipanel(app.figure1);
            app.uipanel6.TitlePosition = 'centertop';
            app.uipanel6.BackgroundColor = [1 1 1];
            app.uipanel6.Tag = 'uipanel6';
            app.uipanel6.FontSize = 11;
            app.uipanel6.Position = [10 249 624 45];

            % Create text24
            app.text24 = uilabel(app.uipanel6);
            app.text24.Tag = 'text24';
            app.text24.BackgroundColor = [1 1 1];
            app.text24.VerticalAlignment = 'top';
            app.text24.FontSize = 11;
            app.text24.Position = [10 7 444 29];
            app.text24.Text = {'Choose the NXP Model-Based Design Toolbox revision you wish to download and install:'; 'Note: Only one version of the Toolbox can be active as Add-Ons. '};

            % Create mbdt_version
            app.mbdt_version = uidropdown(app.uipanel6);
            app.mbdt_version.Items = {'1.5.0', '1.4.0', '1.3.0', '1.2.0', '1.1.0', '1.0.0'};
            app.mbdt_version.Tag = 'mbdt_version';
            app.mbdt_version.FontSize = 11;
            app.mbdt_version.BackgroundColor = [1 1 1];
            app.mbdt_version.Position = [461 15 151 20];
            app.mbdt_version.Value = '1.5.0';

            % Create Help
            app.Help = uibutton(app.figure1, 'push');
            app.Help.ButtonPushedFcn = createCallbackFcn(app, @Help_Callback, true);
            app.Help.Tag = 'Help';
            app.Help.BackgroundColor = [1 1 1];
            app.Help.FontSize = 11;
            app.Help.FontColor = [0 0 1];
            app.Help.Position = [12 15 170 26];
            app.Help.Text = 'Go To Support Site ...';

            % Create NXPPage
            app.NXPPage = uibutton(app.figure1, 'push');
            app.NXPPage.ButtonPushedFcn = createCallbackFcn(app, @NXPPage_Callback, true);
            app.NXPPage.Tag = 'NXPPage';
            app.NXPPage.BackgroundColor = [1 1 1];
            app.NXPPage.FontSize = 11;
            app.NXPPage.FontColor = [0 0 1];
            app.NXPPage.Position = [190 15 170 26];
            app.NXPPage.Text = 'Go To NXP MBDT Site ...';

            % Show the figure after all components are created
            app.figure1.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = NXP_Support_Package_S32K3xx(varargin)

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.figure1)

            % Execute the startup function
            runStartupFcn(app, @(app)NXP_Support_Package_S32K3xx_OpeningFcn(app, varargin{:}))

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.figure1)
        end
    end
end